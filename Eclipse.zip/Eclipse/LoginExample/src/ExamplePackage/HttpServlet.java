package ExamplePackage;

public class HttpServlet {

}
