package com.samplespring.trytwo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
//@Primary    //this will be taken on the Output
public class Mediatek implements MobileProcessor {

	public void process(){
		System.out.println("2nd Best CPU");
	}
}
