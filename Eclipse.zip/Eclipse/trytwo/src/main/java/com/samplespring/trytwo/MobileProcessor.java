package com.samplespring.trytwo;

public interface MobileProcessor {

	void process();
}
