package com.samplespring.NavinReddy;

public interface Vehicle {

	void drive();
}
