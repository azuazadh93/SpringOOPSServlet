package com.samplespring.service;

import java.util.List;

import com.samplespring.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}