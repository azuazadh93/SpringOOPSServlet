package com.samplespring.repository;

import java.util.ArrayList;
import java.util.List;

import com.samplespring.model.Customer;		//imported, since we are working on different package

public class HibernateCustomerRepositoryImpl implements CustomerRepository {

/* (non-Javadoc)
 * @see com.samplespring.repository.CustomerRepository#findAll()
 */
@Override
public List<Customer> findAll() {					//returns customer object
	
	List<Customer> customers = new ArrayList<>();
	
	Customer customer = new Customer();
	
	customer.setFirstname("Abdul");  //assigning First name
	customer.setLastname("Azadh");		//assigning Last name
	
	customers.add(customer); 		//adding the object to customers List
	
	return customers;
			
	
}
}
