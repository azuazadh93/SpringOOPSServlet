package com.samplespring.repository;

import java.util.List;

import com.samplespring.model.Customer;

public interface CustomerRepository {

	List<Customer> findAll();

}