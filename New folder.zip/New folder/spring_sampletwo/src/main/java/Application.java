import com.samplespring.service.CustomerService;
import com.samplespring.service.CustomerServiceImpl;

public class Application {

	public static void main(String[] args) {
	
		CustomerService service = new CustomerServiceImpl();			//getting the instance
		
		System.out.println(service.findAll().get(0).getFirstname());		//This is just to check whether the application returns the input, 

	}

}
