package college;

public class UGStudent implements Student
{
    String name;
    String id;
    int age;
    double grade;
    String address;
    private String degree;
    private String stream;
    public UGStudent(String name, String id, int age, double grade, String address, String degree, String stream)
    {
        this.name = name;
        this.id = id;
        this.age = age;
        this.grade = grade;
        this.address = address;
        this.degree = degree;
        this.stream = stream;
    }
    public void display()
    {
        System.out.println("Name : "+name);
        System.out.println("Id : "+id);
        System.out.println("Age : "+age);
        System.out.println("Grade : "+grade);
        System.out.println("Address : "+address);
        System.out.println("Degree : "+degree);
        System.out.println("Stream : "+stream);



    }

    public boolean isPassed()
    {
        if(this.grade>70)
        {return true;
        }
        else
        {  return false;
        }
    }
}