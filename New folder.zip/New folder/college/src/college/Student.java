package college;

public interface Student {
    void display();
    boolean isPassed();
}
