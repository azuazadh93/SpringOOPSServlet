package com.cts.junit;

public class Add {
	
	public int addition()
	{
		int a= 10,b=20,c;
		System.out.println(c=a+b);
		return c = a+b;
	}
	
	public static void main(String[] args) {
		Add a =new Add();
		a.addition();
	}

}
