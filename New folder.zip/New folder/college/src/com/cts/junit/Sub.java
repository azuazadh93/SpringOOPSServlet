package com.cts.junit;

public class Sub {
	
	public int subtaction()
	{
		int a= 20,b=10,c;
		System.out.println(c=a-b);
		return c = a-b;
	}
	
	public static void main(String[] args) {
		Sub a =new Sub();
		a.subtaction();
	}

}
