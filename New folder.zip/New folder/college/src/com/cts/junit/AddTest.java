package com.cts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddTest {

	@Test
	public void test() {
//		fail("Not yet implemented");
		
		Add add = new Add();
	int output = add.addition();
	assertEquals(30, output);
	
	}

}
