package com.cts.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class SubTest {

	@Test
	public void test() {
		Sub s =new Sub();
		int output1 = s.subtaction();
		assertEquals(10,output1);

	}

}
