import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samplespring.service.CustomerService; 


public class Application {

	public static void main(String[] args) {
	
//		CustomerService service = new CustomerServiceImpl();			//getting the instance
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		CustomerService service = appContext.getBean("customerService", CustomerService.class);	//Bean reference
		System.out.println(service.findAll().get(0).getFirstname());		//This is just to check whether the application returns the input, 

		
	}

}
 