package com.company;

public class Shape {
    protected String shapeName;

    public String getShapeName() {
        return shapeName;
    }
    Shape(String shapeName)
    {
        this.shapeName=shapeName;
    }
    double calculateArea()
    {
        return 0;
    }

}

