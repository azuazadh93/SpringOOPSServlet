package com.company.inher;

public class Main {
}
