package com.company;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {
    public static void main (String args[]) throws IOException {
        BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
        System.out.println("1. Rectangle");
        System.out.println("2. Square");
        System.out.println("3. Circle");
        System.out.println("Area Calculator --- Choose your shape");
        Shape sh=null;
        int n=Integer.parseInt(br.readLine());
        switch(n)
        {
            case 1:
                System.out.println("Enter length and breadth:");
                int l=Integer.parseInt(br.readLine());
                int b=Integer.parseInt(br.readLine());
                sh=new Rectangle( l, b);
                break;
//            case 2:
//                System.out.println("Enter side:");
//                int s=Integer.parseInt(br.readLine());
//                sh=new Square( s);
//                break;
//            case 3:
//                System.out.println("Enter Radius:");
//                int ra=Integer.parseInt(br.readLine());
//                sh=new Circle( ra);
//                break;
        }
        double area=sh.calculateArea();
        System.out.print("Area of "+sh.getShapeName()+" is:");
        System.out.printf("%.2f",area);
    }
}
