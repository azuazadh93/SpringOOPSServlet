package com.cts.interface1;

public interface Student {
    void display();
    boolean isPassed();
}
