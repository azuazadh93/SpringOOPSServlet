package com.cts.Polymor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
public class Main {

  public static void main(String[] args) throws IOException {
      // BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
//public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Menu");
        System.out.println("1.Player");
        System.out.println("2. Runs scored");
        Delivery d = new Delivery();
        int n = sc.nextInt();

        switch(n) {
            case 1:
                System.out.println("Bowler name:");

               String bowler = sc.nextL();
               // String bowler = br.readLine();
//                in.nextLine();

                System.out.println("Batsman name:");
           //     String batsman = br.readLine();
               String batsman = sc.nextLine();
               // System.out.println(batsman+bowler);

                System.exit(0);
                d.displayDeliveryDetails(bowler, batsman);
                System.out.println(batsman+bowler);
                break;

//            case 2:
//
//                System.out.println("Run:");
//                long runs = in.nextLong();
//                d.displayDeliveryDetails(runs);
//                break;
        }
    }
}
