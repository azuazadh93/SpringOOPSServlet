package com.maps.basics;

public class Books {
    private String bookTitle;
    private int noOfCopies;


}
