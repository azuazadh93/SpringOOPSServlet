public class Main
{
    public static void main(String args[])
    {
        Medicine mb = new Medicine(3, 100, 25);
        System.out.println(mb.toString());
    }
}