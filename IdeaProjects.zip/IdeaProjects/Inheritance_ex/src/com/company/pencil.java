package com.company;

public class pencil {

    public void utilize()
    {
        System.out.println("Pencil is being used");
    }

    public static void main(String[] args) {

        write Wrt = new write();
        Wrt.utilize();
        Wrt.drawing();
        Wrt.writing();

    }

}

class draw extends pencil {
    public void drawing() {
        System.out.println("Colors are also being used");
    }
}

class write extends draw {
    public void writing() {
        System.out.println("Article is written");
    }
}