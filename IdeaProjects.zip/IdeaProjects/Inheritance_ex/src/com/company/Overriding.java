package com.company;

import java.awt.*;

public class Overriding {

    public static void main(String[] args) {

        writei Wrt = new writei();
        Wrt.utilize();
//        color col = new color();
//        col.utilize();
    }
}

class pen {

    public void utilize()
    {
        System.out.println("Pencil is being used");
    }
}

class color extends pen {
    public void utilize() {
        System.out.println("Colors are also being used");
    }
}

class writei extends color {
    public void utilize() {
        System.out.println("Article is written");
    }
}