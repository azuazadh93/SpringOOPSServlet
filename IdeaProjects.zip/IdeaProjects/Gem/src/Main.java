
import java.util.Scanner;

public class Main {
    public static void main (String args[])
    {
        Scanner in = new Scanner(System.in);

        System.out.println("1. Rectangle");
        System.out.println("2. Square");
        System.out.println("3. Circle");
        System.out.println("Area Calculator --- Choose your shape");
        int n = in.nextInt();
        Shape sh=null;
        switch(n)
        {
            case 1:
                System.out.println("Enter length:");
                int l = in.nextInt();
                System.out.println("Enter breadth:");
                int b = in.nextInt();
                sh=new Rectangle( l, b);
                break;
            case 2:
                System.out.println("Enter side:");
                int s = in.nextInt();
                sh=new Square(s);
                break;
            case 3:
                System.out.println("Enter Radius:");
                int r= in.nextInt();
                sh=new Circle(r);
                break;
        }
        double area=sh.calculateArea();
        System.out.println("Area is:"+area);

    }
}
