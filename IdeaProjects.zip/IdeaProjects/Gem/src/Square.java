public class Square extends Shape {
    private int side;
    Square(int side)
    {              super("Square");
        this.side=side;
    }
    double calculateArea()
    {
        return side*side;
    }

}