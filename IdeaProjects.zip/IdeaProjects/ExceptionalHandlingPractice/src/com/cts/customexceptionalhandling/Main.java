package com.cts.customexceptionalhandling;

import java.io.*;
public class Main {
    public static void main(String[] args)throws Exception {
        String t1="",t2="";
        int f1=0,f2=0;
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String teams[]={"Chennai Super Kings","Deccan Chargers","Delhi Daredevils","Kings XI Punjab","Kolkata Knight Riders","Mumbai Indians","Rajasthan Royals","Royal Challengers Bangalore"};
            System.out.println("Enter the expected winner team of IPL Season 4");
            t1=br.readLine();
            for(int i=0;i<8;i++)
            {
                if(t1.equals(teams[i]))
                {
                    f1=1;
                    break;
                }
            }
            if(f1==0)
                throw new TeamNameNotFoundException();
            System.out.println("Enter the expected runner Team of IPL Season 4");
            t2=br.readLine();
            for(int i=0;i<8;i++)
            {
                if(t2.equals(teams[i]))
                {
                    f2=1;
                    break;
                }
            }
            if(f2==0)
                throw new TeamNameNotFoundException();
        }catch(TeamNameNotFoundException e)
        {
            System.out.println(e.getClass().getName()+": Entered team is not a part of IPL Season 4");
        }
        if(f1==1&&f2==1)
        {
            System.out.println("Expected IPL Season 4 winner: "+t1);
            System.out.println("Expected IPL Season 4 runner: "+t2);
        }
    }
}


