package com.cts.customexceptionalhandling;

public class TeamNameNotFoundException extends Exception{
    TeamNameNotFoundException()
    {
    }
}

