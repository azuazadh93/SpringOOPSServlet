package com.cts.exceptionalhandling;

import java.io.*;
public class Main {
    public static void main(String args[])throws Exception
    {
        try {
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter the player name");
            String s=br.readLine();
            System.out.println("Enter the player age");
            int a=Integer.parseInt(br.readLine() );
            if(a>=19)
            {
                System.out.println("Player name : "+s);
                System.out.println("Player age : "+a);


            }
            else

                throw new CustomException("InvalidAgeRangeException");
        }
        catch(Exception e) {
            System.out.println(e);

        }




    }
}
