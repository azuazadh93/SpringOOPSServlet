package com.cts.exceptionalhandling;

class CustomException extends Exception
{

    public CustomException(String c)
    {
        super(c);
    }

}
